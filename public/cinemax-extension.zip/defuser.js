// defuser.js - uBlock/Adguard-style Scriptlet for Cinemax Helper
(function() {
  // Only apply inside iframe player contexts
  if (window === window.top) return;

  console.log('[Cinemax Helper] MAIN-world ad-defuser scriptlet active.');

  const adKeywords = [
    'doubleclick', 'syndication', 'popads', 'popcash', 'exoclick', 
    'propeller', 'juicyads', 'adcash', 'clickadu', 'cacuoc', 'gambling',
    'bet', 'cola', 'score', 'xemlive', 'websocket', 'tyso', 'xoilac'
  ];

  // 1. Prevent popups by stubbing window.open
  try {
    window.open = function(url) {
      console.warn('[Cinemax Blocker] Blocked window.open attempt:', url);
      return {
        closed: true,
        focus: function() {},
        blur: function() {},
        close: function() {},
        postMessage: function() {}
      };
    };
  } catch (e) {}

  // 2. Wrap WebSocket connections to prevent ad WebSockets
  try {
    const OriginalWebSocket = window.WebSocket;
    window.WebSocket = function(url, protocols) {
      const lowUrl = String(url).toLowerCase();
      if (adKeywords.some(kw => lowUrl.includes(kw))) {
        console.warn('[Cinemax Blocker] Blocked ad WebSocket connection:', url);
        throw new Error('WebSocket connection blocked by Cinemax');
      }
      return new OriginalWebSocket(url, protocols);
    };
    window.WebSocket.prototype = OriginalWebSocket.prototype;
  } catch (e) {}

  // 3. Disable WebRTC to block peer-to-peer advertising networks and IP leaks
  try {
    if (window.RTCPeerConnection) {
      window.RTCPeerConnection = function() {
        console.warn('[Cinemax Blocker] WebRTC connection disabled inside player iframe');
        throw new Error('WebRTC disabled by Cinemax');
      };
    }
  } catch (e) {}

  // 4. Overwrite setAttribute to prevent ad-script/ad-iframe injection
  try {
    const originalSetAttribute = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(name, value) {
      if (String(name).toLowerCase() === 'src') {
        const tagName = this.tagName.toLowerCase();
        if (tagName === 'script' || tagName === 'iframe') {
          const lowVal = String(value).toLowerCase();
          if (adKeywords.some(kw => lowVal.includes(kw))) {
            console.warn('[Cinemax Blocker] Blocked setAttribute(src) injection:', value);
            return;
          }
        }
      }
      originalSetAttribute.apply(this, arguments);
    };
  } catch (e) {}

  // 5. Overwrite prototype src setters for script and iframe elements
  try {
    const originalScriptSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
    if (originalScriptSrcDescriptor && originalScriptSrcDescriptor.set) {
      Object.defineProperty(HTMLScriptElement.prototype, 'src', {
        get() {
          return originalScriptSrcDescriptor.get.call(this);
        },
        set(val) {
          const lowVal = String(val).toLowerCase();
          if (adKeywords.some(kw => lowVal.includes(kw))) {
            console.warn('[Cinemax Blocker] Blocked script.src property assignment:', val);
            return;
          }
          originalScriptSrcDescriptor.set.call(this, val);
        }
      });
    }

    const originalIFrameSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
    if (originalIFrameSrcDescriptor && originalIFrameSrcDescriptor.set) {
      Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
        get() {
          return originalIFrameSrcDescriptor.get.call(this);
        },
        set(val) {
          const lowVal = String(val).toLowerCase();
          if (adKeywords.some(kw => lowVal.includes(kw))) {
            console.warn('[Cinemax Blocker] Blocked iframe.src property assignment:', val);
            return;
          }
          originalIFrameSrcDescriptor.set.call(this, val);
        }
      });
    }
  } catch (e) {}

  // 6. Block click-triggered _blank window openings (capturing phase)
  try {
    window.addEventListener('click', (e) => {
      if (e.target && e.target.tagName === 'A' && e.target.target === '_blank') {
        console.warn('[Cinemax Blocker] Intercepted and blocked _blank anchor click:', e.target.href);
        e.preventDefault();
        e.stopPropagation();
      }
    }, true);
  } catch (e) {}
})();
